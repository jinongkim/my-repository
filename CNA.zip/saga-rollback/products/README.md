# products
상품 추가시 상품 옵션은 OneToMany <-> ManyToOne 관계  


http POST http://localhost:8085/products name=TENT price=3000 stock=10

http POST http://localhost:8085/product < productData.json 