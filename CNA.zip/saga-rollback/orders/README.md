# orders
http http://localhost:8081/orders productId=2 quantity=3 customerId=1@uengine.org