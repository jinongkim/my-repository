package com.example.template.product;

import org.springframework.data.repository.CrudRepository;

public interface ProductOptionRepository extends CrudRepository<ProductOption, Long> {
}
