package com.example.template.order;

import org.springframework.stereotype.Service;

@Service
public class OrderService {

}
